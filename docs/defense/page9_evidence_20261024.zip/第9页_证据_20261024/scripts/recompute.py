#!/usr/bin/env python3
"""第 9 页数字复算（只用标准库）。

    python3 recompute.py            # 打印 + 另存 复算结果.txt
"""
from __future__ import annotations

import csv
import statistics as st
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE.parent / "data" if HERE.name == "scripts" else Path("data")

CASES = (("test_gust_0_pitch0.055", "1", "有效场景：阵风 2.7 MW"),
         ("test_ramp_2_pitch0.025", "1", "不足场景：慢变 3.9 MW"))
NAMES = {"initial": "初始 MADDPG", "fixed": "固定桨距", "p": "P 控制",
         "pi": "PI 控制", "final": "训练后 MADDPG"}


def rows(p):
    with open(p, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def main():
    out = []
    m = rows(DATA / "metrics.csv")
    reg = [r for r in m if r["family"] != "low_wind_stress"]
    out.append(f"指标总条数 {len(m)}；常规场 {len(reg)} 条")
    means = {}
    for k in ("initial", "fixed", "p", "pi", "final"):
        v = [float(r["rmse_w"]) / 1000 for r in reg if r["controller"] == k]
        means[k] = st.mean(v)
        out.append(f"  {NAMES[k]:<12} {len(v):>3} 场  平均 RMSE {means[k]:8.2f} kW")
    streams = [st.mean([float(r["rmse_w"]) / 1000 for r in reg
                        if r["controller"] == "final" and r["run_id"] == i]) for i in "012"]
    out.append("  三条流：" + " / ".join(f"{x:.2f}" for x in streams)
               + f"  均值的均值 {st.mean(streams):.2f}  样本标准差 {st.stdev(streams):.2f}")
    out.append(f"  相对初始 {(1-means['final']/means['initial'])*100:.1f}%"
               f"；相对 PI {(1-means['final']/means['pi'])*100:.1f}%")
    for fam, lab in (("gust", "阵风"), ("stationary", "平稳"), ("ramp", "慢变"),
                     ("low_wind_stress", "低风压力场")):
        f = {k: st.mean([float(r["rmse_w"]) / 1000 for r in m
                         if r["family"] == fam and r["controller"] == k])
             for k in ("final", "p", "pi")}
        out.append(f"  {lab:<6} MADDPG {f['final']:8.2f}  P {f['p']:8.2f}  PI {f['pi']:8.2f}")
    t = rows(DATA / "trajectories.csv")
    for case, run, lab in CASES:
        out.append(f"  [{lab}]")
        for k, rid in (("initial", run), ("p", "-1"), ("pi", "-1"), ("final", run)):
            v = [r for r in t if r["case_id"] == case and r["controller"] == k
                 and r["run_id"] == rid]
            if not v:
                continue
            rmse = (sum(float(r["error_w"]) ** 2 for r in v) / len(v)) ** 0.5 / 1000
            out.append(f"    {NAMES[k]:<12} {len(v):>3} 步  RMSE {rmse:7.1f} kW")
    text = "\n".join(out)
    print(text)
    (HERE / "复算结果.txt").write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
